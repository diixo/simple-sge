/*___INFO__MARK_BEGIN__*/
/***************************************************************************
 *
 *  The contents of this file are made available subject to the terms of the
 *  Apache Software License 2.0 ('The License').
 *  You may not use this file except in compliance with The License.
 *  You may obtain a copy of The License at
 *  http://www.apache.org/licenses/LICENSE-2.0.html
 *
 *  Copyright (c) 2011 Univa Corporation.
 *
 ***************************************************************************/
/*___INFO__MARK_END__*/

int WriteToLogFile(const char *szMessage, ...);
