/* $Header: /p/tcsh/cvsroot/tcsh/patchlevel.h,v 3.167 2009/07/10 17:09:32 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 17
#define PATCHLEVEL 0
#define DATE "2009-07-10"

#endif /* _h_patchlevel */
